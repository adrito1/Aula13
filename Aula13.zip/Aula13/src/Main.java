public class Main {
    public static void main(String[] args) {
        controlador controlador = new controlador();
        int elementoParaEncontrar = 93;
        controlador.buscarElemento(elementoParaEncontrar);
    }
}
