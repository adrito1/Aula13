public class controlador {
    private BuscaSequencial buscaSequencial;
    private visao visao;

    public controlador() {
        this.buscaSequencial = new BuscaSequencial();
        this.visao = new visao();
    }

    public void buscarElemento(int elemento) {
        int resultado = buscaSequencial.buscaSequencial(elemento);
        visao.mostrarResultado(resultado);
    }
}
